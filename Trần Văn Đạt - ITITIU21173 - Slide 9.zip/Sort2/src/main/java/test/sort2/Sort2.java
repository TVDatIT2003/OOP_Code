/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package test.sort2;

/**
 *
 * @author acer
 */
import java.util.List;  
import java.util.Arrays; 
import java.util.Collections;

public class Sort2 {

    public static void main(String[] args) {
        String[] suits = { "Hearts", "Diamonds", "Clubs", "Spades" }; 
        
        // Create and display a list containing the suits array elements 
        List< String > list = Arrays.asList( suits ); // create List 
        System.out.printf( "Unsorted array elements: %s\n", list ); 
        
         // sort in descending order
        Collections.sort( list, Collections.reverseOrder() ); 
        
        // output list 
        System.out.printf( "Sorted array elements: %s\n", list );
    }
}
