/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package test.shapestest;

/**
 *
 * @author acer
 */
import javax.swing.JFrame;

public class ShapesTest {

    public static void main(String[] args) {
         //Create frame for ShapesJPanel 
         JFrame frame = new JFrame ("Drawing 2D shapes"); 
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        // create ShapesJPanel 
        ShapesJPanel shapesJPanel = new ShapesJPanel(); 
        frame.add(shapesJPanel); 
        frame.setSize(425, 200); 
        frame.setVisible(true); ;
    }
}
