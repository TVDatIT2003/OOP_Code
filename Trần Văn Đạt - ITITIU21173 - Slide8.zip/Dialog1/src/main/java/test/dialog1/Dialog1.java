/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package test.dialog1;

/**
 *
 * @author acer
 */
import javax.swing.JOptionPane;

public class Dialog1 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to Java");
    }
}
