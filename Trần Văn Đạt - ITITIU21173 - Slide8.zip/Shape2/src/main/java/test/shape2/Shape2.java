/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package test.shape2;

/**
 *
 * @author acer
 */
import java.awt.Color;  
import javax.swing.JFrame;

public class Shape2 {

    public static void main(String[] args) {
         // create frame for Shapes2JPanel 
         JFrame frame = new JFrame("Drawing 2D Shapes"); 
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
         
         Shape2JPanel shape2JPanel = new Shape2JPanel(); 
         frame.add(shape2JPanel); 
         frame.setBackground(Color.WHITE); 
         frame.setSize(315, 330); 
         frame.setVisible(true);
    }
}
