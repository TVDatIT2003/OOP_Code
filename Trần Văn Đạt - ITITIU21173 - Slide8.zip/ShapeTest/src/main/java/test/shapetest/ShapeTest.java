/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package test.shapetest;

/**
 *
 * @author acer
 */
import javax.swing.JOptionPane;
import javax.swing.JFrame;

public class ShapeTest {

    public static void main(String[] args) {
        //User's choice
        String input = JOptionPane.showInputDialog("Enter 1 to draw rectangles\n" + "Enter 2 to draw ovals");
        
        int choice = Integer.parseInt(input);
        
        //Create panel
        Shapes panel = new Shapes(choice);
        JFrame application = new JFrame();
        
        //Set the frame to exit when it is closed
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        application.add(panel);//add the panel to the frame
        application.setSize(300, 300);//set the size of the frame
        application.setVisible(true);//make the frame visible
    }
}
