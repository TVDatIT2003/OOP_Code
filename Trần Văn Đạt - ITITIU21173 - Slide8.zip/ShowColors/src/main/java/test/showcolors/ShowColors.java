/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package test.showcolors;



/**
 *
 * @author acer
 */
import javax.swing.JFrame;

public class ShowColors {

    public static void main(String[] args) {
        JFrame frame  = new JFrame("Using colors");     
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        ColorJPanel colorJPanel = new ColorJPanel();
        frame.add(colorJPanel);//add the panel to the frame
        frame.setSize(400, 180);//set the size of the frame
        frame.setVisible(true);//make the frame visible
    }
}
